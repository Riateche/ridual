<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru" sourcelanguage="en">
<context>
    <name>Main_window</name>
    <message>
        <location filename="src/Main_window.ui" line="14"/>
        <source>ridual</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Pane</name>
    <message>
        <location filename="src/Pane.ui" line="31"/>
        <source>Go</source>
        <translation>OK</translation>
    </message>
</context>
</TS>
