#ifndef UTILS_H
#define UTILS_H

#include <QString>

QString get_mime_type(const QString &filename);

#endif // UTILS_H
